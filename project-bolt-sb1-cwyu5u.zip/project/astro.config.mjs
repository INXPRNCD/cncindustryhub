import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';
import sitemap from '@astrojs/sitemap';
import prefetch from '@astrojs/prefetch';

export default defineConfig({
  site: 'https://www.cncindustryhub.com',
  trailingSlash: 'never',
  integrations: [
    tailwind(),
    prefetch(),
    sitemap({
      lastmod: new Date(),
      filter: (page) => !page.includes('404'),
      serialize: (item) => ({
        ...item,
        changefreq: item.url === '/' ? 'daily' : 'weekly',
        priority: item.url === '/' ? 1.0 : 0.7
      })
    })
  ],
  build: {
    inlineStylesheets: 'auto'
  },
  vite: {
    build: {
      cssCodeSplit: false
    },
    ssr: {
      noExternal: ['@fontsource/*']
    }
  }
});